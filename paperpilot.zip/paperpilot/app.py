"""PaperPilot - Streamlit dashboard. Run: streamlit run app.py"""
from pathlib import Path

import streamlit as st

from paperpilot.pipeline import run
from paperpilot.quiz_generator import ai_available, ai_mcqs, self_test_cards
from paperpilot.study_planner import make_plan

st.set_page_config(page_title="PaperPilot", page_icon="🧭", layout="wide")
st.title("🧭 PaperPilot")
st.caption("Past papers upload karo, aur dekho ke kaun se topics sab se zyada aate hain.")

with st.sidebar:
    st.header("Papers")
    uploads = st.file_uploader("PDF / TXT upload karo", type=["pdf", "txt"],
                               accept_multiple_files=True)
    use_sample = st.checkbox("Sample papers use karo", value=not uploads)
    n_topics = st.slider("Topics ki tadaad", 2, 12, 7)

files = {u.name: u.read() for u in uploads or []}
if use_sample and not files:
    for p in sorted(Path("sample_papers").glob("*.pdf")):
        files[p.name] = p.read_bytes()

if not files:
    st.info("Sidebar se papers upload karo ya sample papers on karo.")
    st.stop()

qdf, tdf = run(files, n_topics)
if tdf.empty:
    st.error("Koi questions nahi mile. Agar PDF scanned hai to pehle OCR karna hoga.")
    st.stop()

c1, c2, c3 = st.columns(3)
c1.metric("Papers", qdf["paper"].nunique())
c2.metric("Total questions", len(qdf))
c3.metric("Topics", len(tdf))

tab_dash, tab_plan, tab_quiz = st.tabs(["📊 Dashboard", "🗓️ Study planner", "📝 Practice"])

with tab_dash:
    st.subheader("🔥 Top important topics")
    st.bar_chart(tdf.set_index("topic")["importance"])
    st.dataframe(
        tdf.rename(columns={"questions": "Questions", "papers": "Papers mein aaya",
                            "importance": "Importance (0-100)", "topic": "Topic"}),
        width="stretch", hide_index=True,
    )

    st.subheader("Topic ke questions dekho")
    for topic in tdf["topic"]:
        sub = qdf[qdf["topic"] == topic]
        with st.expander(f"{topic}  ({len(sub)} questions)"):
            for _, r in sub.iterrows():
                st.markdown(f"- **{r['paper']}**: {r['question']}")

    st.download_button("Results CSV download karo", qdf.to_csv(index=False),
                       "paperpilot_results.csv", "text/csv")

with tab_plan:
    st.subheader("Exam se pehle ka plan")
    a, b = st.columns(2)
    days = a.number_input("Exam mein kitne din bache hain?", 1, 60, 10)
    hrs = b.number_input("Rozana kitne ghante parh sakte ho?", 0.5, 12.0, 3.0, step=0.5)
    plan = make_plan(tdf, days, hrs)
    for d, g in plan.groupby("day"):
        st.markdown(f"**Day {d}**")
        for _, r in g.iterrows():
            st.write(f"- {r['topic']}: {r['hours']} ghante")

with tab_quiz:
    st.subheader("Practice karo")
    topic = st.selectbox("Topic chuno", tdf["topic"])
    qs = qdf.loc[qdf["topic"] == topic, "question"].tolist()
    if ai_available():
        st.caption("AI mode on (ANTHROPIC_API_KEY mili).")
        if st.button("AI se MCQs banao"):
            try:
                st.session_state["mcqs"] = ai_mcqs(topic, qs)
            except Exception as e:
                st.error(f"AI request fail hui: {e}")
        for i, m in enumerate(st.session_state.get("mcqs", [])):
            pick = st.radio(f"{i+1}. {m['question']}", m["options"], index=None, key=f"mcq{i}")
            if pick is not None:
                ok = m["options"].index(pick) == m["answer_index"]
                st.success("Sahi!") if ok else st.error("Ghalat.")
                st.caption(m["explanation"])
    else:
        st.caption("Offline mode: pehle khud jawab likho, phir key terms se check karo. "
                   "(AI MCQs ke liye ANTHROPIC_API_KEY set karo.)")
    for c in self_test_cards(qs, 5):
        with st.expander(c["question"]):
            st.write("Jawab mein yeh terms hone chahiye: " + ", ".join(f"`{t}`" for t in c["must_mention"]))
