# 🧭 PaperPilot

Upload past exam papers (PDF/TXT) and PaperPilot tells you **which topics appear most
often**, so you know what to study first.

## How it works
1. **Extract** text from each PDF (PyMuPDF)
2. **Split** the text into individual questions (regex: `Q1.`, `2)`, `Question 3:` ...)
3. **Cluster** questions into topics (TF-IDF + KMeans) and label each topic with its top keywords
4. **Rank** topics by *importance* = 60% question share + 40% consistency across papers
5. **Show** everything in a Streamlit dashboard, with CSV export
6. **Plan**: day-by-day study schedule from days left + hours per day
7. **Practice**: self-test cards (offline) or AI multiple-choice questions (optional)

## Run it
```bash
pip install -r requirements.txt
streamlit run app.py
```
Sample papers are included in `sample_papers/` (regenerate with `python make_samples.py`).

## Optional: AI quiz
```bash
export ANTHROPIC_API_KEY=your_key   # Windows: set ANTHROPIC_API_KEY=your_key
streamlit run app.py
```
The Practice tab then shows an "AI se MCQs banao" button. Without a key it uses offline self-test cards.

## Tests
```bash
pytest -q
```

## Project structure
```
paperpilot/
├── app.py                     # Streamlit dashboard
├── paperpilot/
│   ├── pdf_parser.py          # PDF/TXT -> text
│   ├── question_splitter.py   # text -> questions
│   ├── topic_analyzer.py      # questions -> topics + importance
│   ├── study_planner.py       # topics -> daily schedule
│   ├── quiz_generator.py      # practice cards / AI MCQs
│   └── pipeline.py            # glues the steps together
├── sample_papers/
├── tests/
└── make_samples.py
```

## Limitations
- OCR for scanned PDFs needs Tesseract installed (`apt install tesseract-ocr` / Windows installer); without it, scanned pages are skipped.
- Topic labels are keywords, not clean names (planned: LLM-generated labels).
- Question splitting assumes numbered questions; unusual layouts may need tweaks.

## Roadmap
- [x] OCR for scanned papers
- [x] Study planner
- [x] Practice cards + optional AI MCQs
- [ ] LLM-generated topic names and short notes
- [ ] Chat with your notes (RAG)
- [ ] Study planner based on days left before the exam
- [ ] Roman Urdu / Urdu paper support
- [ ] Measure accuracy on a hand-labelled set of 100 questions
