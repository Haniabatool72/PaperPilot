"""Turn ranked topics into a day-by-day study schedule."""
from __future__ import annotations

import pandas as pd


def make_plan(topics_df: pd.DataFrame, days_left: int, hours_per_day: float = 3.0) -> pd.DataFrame:
    """Spread study hours over the days left, more time for important topics.

    The last day (if there are 3+ days) is kept for quick revision of the top 3 topics.
    Returns columns: day, topic, hours.
    """
    if topics_df.empty:
        return pd.DataFrame(columns=["day", "topic", "hours"])

    days_left = max(1, int(days_left))
    has_revision = days_left >= 3
    study_days = days_left - 1 if has_revision else days_left

    weights = topics_df["importance"] / topics_df["importance"].sum()
    budget = study_days * hours_per_day
    rows, day, free = [], 1, hours_per_day

    for topic, w in zip(topics_df["topic"], weights):
        need = w * budget
        while need > 0.05 and day <= study_days:
            take = min(need, free)
            rows.append({"day": day, "topic": topic, "hours": round(take, 1)})
            need -= take
            free -= take
            if free <= 0.05:
                day, free = day + 1, hours_per_day

    if has_revision:
        top = topics_df["topic"].head(3)
        for t in top:
            rows.append({"day": days_left, "topic": f"Revision: {t}",
                         "hours": round(hours_per_day / len(top), 1)})
    return pd.DataFrame(rows)
