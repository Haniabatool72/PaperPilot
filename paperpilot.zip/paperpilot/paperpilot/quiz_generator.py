"""Practice material for a topic.

Two modes:
  * offline (default): self-test cards = past question + key terms to mention
  * AI (optional): multiple-choice questions from Claude, if ANTHROPIC_API_KEY is set
"""
from __future__ import annotations

import json
import os
import re
import urllib.request
from collections import Counter

from .topic_analyzer import STOP_WORDS

_STOP = set(STOP_WORDS)
MODEL = "claude-sonnet-5-5"


def key_terms(question: str, n: int = 4) -> list[str]:
    """Most useful words in a question: not a stop word, longer words first."""
    words = re.findall(r"[a-zA-Z][a-zA-Z0-9\-']{2,}", question.lower())
    counts = Counter(w for w in words if w not in _STOP)
    return [w for w, _ in sorted(counts.items(), key=lambda x: (-x[1], -len(x[0])))[:n]]


def self_test_cards(questions: list[str], n: int = 5) -> list[dict]:
    """Offline practice: each card = a question and the terms a good answer includes."""
    return [{"question": q, "must_mention": key_terms(q)} for q in questions[:n]]


def ai_available() -> bool:
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


def ai_mcqs(topic: str, questions: list[str], n: int = 5) -> list[dict]:
    """Ask Claude for n MCQs. Returns [{question, options[4], answer_index, explanation}]."""
    prompt = (
        f"Topic: {topic}\nPast exam questions on this topic:\n- "
        + "\n- ".join(questions[:10])
        + f"\n\nWrite {n} new multiple-choice practice questions for this topic. "
        "Reply ONLY with a JSON list; each item has keys: question, options (4 strings), "
        "answer_index (0-3), explanation."
    )
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps({"model": MODEL, "max_tokens": 1500,
                         "messages": [{"role": "user", "content": prompt}]}).encode(),
        headers={"content-type": "application/json",
                 "x-api-key": os.environ["ANTHROPIC_API_KEY"],
                 "anthropic-version": "2023-06-01"},
    )
    with urllib.request.urlopen(req, timeout=60) as r:
        text = json.load(r)["content"][0]["text"]
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()
    return json.loads(text)
