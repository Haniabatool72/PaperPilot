"""PaperPilot: find the most important topics from past papers."""
