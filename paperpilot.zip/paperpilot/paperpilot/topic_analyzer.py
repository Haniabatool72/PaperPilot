"""Group questions into topics and rank them by importance."""
from __future__ import annotations

import pandas as pd
from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS, TfidfVectorizer

# Words that appear in every exam and carry no topic meaning.
EXAM_WORDS = {
    "explain", "define", "write", "marks", "mark", "short", "note", "notes",
    "discuss", "describe", "state", "differentiate", "difference", "between",
    "following", "give", "example", "examples", "briefly", "detail", "list",
    "what", "why", "how", "which", "attempt", "question", "questions", "answer",
    "using", "use", "used", "also", "any", "each", "diagram", "compare",
    "ka", "ki", "ke", "hai", "kya", "aur", "ko", "se", "mein", "likho",
}
STOP_WORDS = list(ENGLISH_STOP_WORDS | EXAM_WORDS)


def analyze(questions_by_paper: dict[str, list[str]], n_topics: int | None = None):
    """Cluster all questions and rank the topics.

    Returns (questions_df, topics_df).
      questions_df: paper, question, topic_id, topic
      topics_df:    topic, questions, papers, importance (0-100)
    """
    rows = [
        {"paper": paper, "question": q}
        for paper, qs in questions_by_paper.items()
        for q in qs
    ]
    if len(rows) < 2:
        return pd.DataFrame(rows), pd.DataFrame()

    qdf = pd.DataFrame(rows)
    vec = TfidfVectorizer(stop_words=STOP_WORDS, ngram_range=(1, 2), min_df=1,
                          sublinear_tf=True)
    X = vec.fit_transform(qdf["question"])

    k = n_topics or min(8, max(2, len(qdf) // 4))
    k = max(1, min(k, len(qdf)))
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X)
    qdf["topic_id"] = km.labels_

    terms = vec.get_feature_names_out()
    labels = {}
    for cid in range(k):
        top = km.cluster_centers_[cid].argsort()[::-1][:3]
        labels[cid] = ", ".join(terms[i] for i in top)
    qdf["topic"] = qdf["topic_id"].map(labels)

    n_papers = max(1, qdf["paper"].nunique())
    tdf = (
        qdf.groupby("topic")
        .agg(questions=("question", "count"), papers=("paper", "nunique"))
        .reset_index()
    )
    # Importance: how many questions AND how consistently across years.
    share = tdf["questions"] / tdf["questions"].sum()
    coverage = tdf["papers"] / n_papers
    tdf["importance"] = ((0.6 * share / share.max() + 0.4 * coverage) * 100).round(1)
    tdf = tdf.sort_values("importance", ascending=False).reset_index(drop=True)
    return qdf, tdf
