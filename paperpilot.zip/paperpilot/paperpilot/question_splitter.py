"""Split raw exam-paper text into individual questions."""
from __future__ import annotations

import re

# Matches line starts like: "Q1.", "Q. 2)", "Question 3:", "4.", "5)"
_START = re.compile(
    r"^\s*(?:(?:q|question)\.?\s*)?(\d{1,2})\s*[.):\-]\s+(?=\S)",
    re.IGNORECASE | re.MULTILINE,
)
_MARKS = re.compile(r"[\[\(]\s*\d+\s*(?:marks?|pts?)?\s*[\]\)]", re.IGNORECASE)


def split_questions(text: str, min_chars: int = 15) -> list[str]:
    """Return a list of cleaned question strings found in `text`."""
    matches = list(_START.finditer(text))
    if not matches:
        # Fallback: treat each non-empty line as a question.
        chunks = [ln for ln in text.splitlines() if len(ln.strip()) >= min_chars]
    else:
        chunks = []
        for i, m in enumerate(matches):
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
            chunks.append(text[m.end():end])

    cleaned = []
    for c in chunks:
        c = _MARKS.sub(" ", c)
        c = re.sub(r"\s+", " ", c).strip()
        if len(c) >= min_chars:
            cleaned.append(c)
    return cleaned
