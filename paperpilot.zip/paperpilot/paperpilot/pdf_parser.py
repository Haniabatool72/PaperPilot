"""Extract text from uploaded past papers (PDF or TXT), with optional OCR."""
from __future__ import annotations

import pymupdf


def extract_text(data: bytes, filename: str = "paper.pdf", ocr: bool = True) -> str:
    """Return the text of a PDF/TXT file.

    If a page has no text layer (scanned) and `ocr` is True, PyMuPDF's OCR is
    tried. That needs Tesseract installed; if it is missing we just skip.
    """
    if filename.lower().endswith(".txt"):
        return data.decode("utf-8", errors="ignore")

    pages = []
    with pymupdf.open(stream=data, filetype="pdf") as doc:
        for page in doc:
            text = page.get_text()
            if not text.strip() and ocr:
                text = _ocr_page(page)
            pages.append(text)
    return "\n".join(pages)


def _ocr_page(page) -> str:
    try:
        tp = page.get_textpage_ocr(dpi=200, full=True)
        return page.get_text(textpage=tp)
    except Exception:  # Tesseract missing or failed
        return ""
