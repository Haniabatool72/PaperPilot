"""End-to-end helper used by the app and tests."""
from __future__ import annotations

from .pdf_parser import extract_text
from .question_splitter import split_questions
from .topic_analyzer import analyze


def run(files: dict[str, bytes], n_topics: int | None = None):
    """files: {filename: bytes}. Returns (questions_df, topics_df)."""
    by_paper = {}
    for name, data in files.items():
        qs = split_questions(extract_text(data, name))
        if qs:
            by_paper[name] = qs
    return analyze(by_paper, n_topics)
