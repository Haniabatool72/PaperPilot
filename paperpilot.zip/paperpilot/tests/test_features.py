from pathlib import Path

import pymupdf

from paperpilot.pdf_parser import extract_text
from paperpilot.pipeline import run
from paperpilot.quiz_generator import key_terms, self_test_cards
from paperpilot.study_planner import make_plan

SAMPLES = Path(__file__).parent.parent / "sample_papers"


def _topics():
    files = {p.name: p.read_bytes() for p in SAMPLES.glob("*.pdf")}
    return run(files, 7)


def test_plan_fits_budget_and_has_revision():
    _, tdf = _topics()
    plan = make_plan(tdf, days_left=10, hours_per_day=3)
    assert plan["day"].max() == 10
    daily = plan[~plan["topic"].str.startswith("Revision")].groupby("day")["hours"].sum()
    assert (daily <= 3.2).all()
    assert plan["topic"].str.startswith("Revision").sum() == 3


def test_plan_short_time_has_no_revision_day():
    _, tdf = _topics()
    plan = make_plan(tdf, days_left=2, hours_per_day=2)
    assert plan["day"].max() <= 2


def test_key_terms_and_cards():
    assert "deadlock" in key_terms("Explain deadlock prevention using the banker's algorithm")
    cards = self_test_cards(["Explain CPU scheduling algorithms and calculate waiting time"], 1)
    assert cards[0]["must_mention"]


def test_ocr_on_scanned_pdf():
    # Build an image-only PDF: render text to a pixmap, then embed it as an image.
    src = pymupdf.open()
    p = src.new_page()
    p.insert_text((50, 100), "Q1. Explain database normalization with examples", fontsize=18)
    pix = p.get_pixmap(dpi=200)
    scanned = pymupdf.open()
    sp = scanned.new_page()
    sp.insert_image(sp.rect, pixmap=pix)
    data = scanned.tobytes()
    assert extract_text(data, "scan.pdf", ocr=False).strip() == ""
    assert "normalization" in extract_text(data, "scan.pdf", ocr=True).lower()
