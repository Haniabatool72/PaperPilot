from pathlib import Path

from paperpilot.pipeline import run
from paperpilot.question_splitter import split_questions

SAMPLES = Path(__file__).parent.parent / "sample_papers"


def test_split_questions_basic():
    text = "Q1. Define normalization in databases. [5 marks]\nQ2. Explain deadlock in OS.\n3) What is the TCP protocol?"
    qs = split_questions(text)
    assert len(qs) == 3
    assert "marks" not in qs[0]


def test_split_falls_back_to_lines():
    qs = split_questions("Explain the OSI model in detail\nDescribe paging in memory")
    assert len(qs) == 2


def test_pipeline_on_samples():
    files = {p.name: p.read_bytes() for p in SAMPLES.glob("*.pdf")}
    qdf, tdf = run(files, n_topics=5)
    assert qdf["paper"].nunique() == 3
    assert len(qdf) == 24
    assert tdf["importance"].max() <= 100
    assert tdf.iloc[0]["papers"] == 3  # top topic appears in every paper
