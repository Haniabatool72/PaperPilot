"""Generate 3 small sample PDFs so anyone can try PaperPilot instantly."""
import pymupdf as fitz

PAPERS = {
    "cs_paper_2022.pdf": [
        "Define normalization. Explain 1NF, 2NF and 3NF with examples. [5 marks]",
        "What is a deadlock? Explain the conditions necessary for deadlock. [5 marks]",
        "Explain the OSI model and describe the function of each layer. [5 marks]",
        "Write SQL queries using JOIN and GROUP BY on a student table. [5 marks]",
        "Differentiate between process and thread in an operating system. [5 marks]",
        "Explain TCP three-way handshake with a diagram. [5 marks]",
        "What is a primary key and a foreign key in a database? [5 marks]",
        "Describe CPU scheduling algorithms: FCFS, SJF and Round Robin. [5 marks]",
    ],
    "cs_paper_2023.pdf": [
        "Explain database normalization and its advantages with examples. [5 marks]",
        "Discuss deadlock prevention and deadlock avoidance using the banker's algorithm. [5 marks]",
        "Compare the OSI model with the TCP/IP model. [5 marks]",
        "Write SQL queries for INSERT, UPDATE and JOIN operations on tables. [5 marks]",
        "Explain round robin and priority CPU scheduling with a Gantt chart. [5 marks]",
        "What is IP addressing? Explain subnetting with an example. [5 marks]",
        "Describe ACID properties of database transactions. [5 marks]",
        "Explain paging and virtual memory in an operating system. [5 marks]",
    ],
    "cs_paper_2024.pdf": [
        "Define normalization and convert a given table into 3NF. [5 marks]",
        "Explain deadlock detection and recovery in operating systems. [5 marks]",
        "Explain the layers of the OSI model and the protocols at each layer. [5 marks]",
        "Write SQL queries using GROUP BY, HAVING and JOIN on employee data. [5 marks]",
        "Explain CPU scheduling algorithms and calculate average waiting time. [5 marks]",
        "What is DNS? Explain how routing and IP addressing work in networks. [5 marks]",
        "Explain database indexing and transactions with the ACID properties. [5 marks]",
        "Describe page replacement algorithms in virtual memory. [5 marks]",
    ],
}

for fname, qs in PAPERS.items():
    doc = fitz.open()
    page = doc.new_page()
    y = 60
    page.insert_text((50, y), f"Computer Science - {fname[9:13]}", fontsize=14)
    y += 30
    for i, q in enumerate(qs, 1):
        page.insert_textbox(fitz.Rect(50, y, 545, y + 50), f"Q{i}. {q}", fontsize=10)
        y += 55
    doc.save(f"sample_papers/{fname}")
print("done")
